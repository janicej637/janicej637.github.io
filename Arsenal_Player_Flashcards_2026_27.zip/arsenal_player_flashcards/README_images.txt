# Arsenal Player Flashcards

This package contains the updated four-radio-button Arsenal flashcard game.

## Important: player photographs

The `images` folder is intentionally empty.

The photographs shown in Arsenal's official player profiles are copyrighted club/media assets. I have therefore not repackaged those photographs into this ZIP. Instead, this README gives you the official Arsenal player pages to use as your source.

For the website to display the local images, save each photograph into the `images` folder using the exact filename listed below.

## Files required

- images/david-raya.jpg
- images/william-saliba.jpg
- images/gabriel-magalhaes.jpg
- images/jurrien-timber.jpg
- images/piero-hincapie.jpg
- images/riccardo-calafiori.jpg
- images/declan-rice.jpg
- images/martin-zubimendi.jpg
- images/martin-odegaard.jpg
- images/eberechi-eze.jpg
- images/bukayo-saka.jpg
- images/noni-madueke.jpg
- images/gabriel-martinelli.jpg
- images/viktor-gyokeres.jpg
- images/christos-tzolis.jpg
- images/bruno-guimaraes.jpg

## Official Arsenal sources

Use Arsenal's official website/player pages as the source for the photographs.

Arsenal men's player directory:
https://www.arsenal.com/fixtures/men/players

Examples:
https://www.arsenal.com/men/players/david-raya
https://www.arsenal.com/men/players/william-saliba
https://www.arsenal.com/men/players/declan-rice
https://www.arsenal.com/fixtures/men/players/bukayo-saka-alSZJ1E2zPCV

Arsenal's official site also has current 2026/27 squad and transfer information:
https://www.arsenal.com/news/arsenal-transfers-all-the-ins-and-outs-in-202627-a8qx29v8B1fR

## How to add the photographs

1. Open the Arsenal player page.
2. Save an appropriate player photograph.
3. Rename it to the exact filename above.
4. Put the file inside the `images` folder.
5. Upload `index10.html` and the `images` folder to GitHub.
6. Open the GitHub Pages version of the page.

## Current player set

The game uses 16 players:

David Raya
William Saliba
Gabriel Magalhaes
Jurrien Timber
Piero Hincapie
Riccardo Calafiori
Declan Rice
Martin Zubimendi
Martin Odegaard
Eberechi Eze
Bukayo Saka
Noni Madueke
Gabriel Martinelli
Viktor Gyokeres
Christos Tzolis
Bruno Guimaraes

The 2026/27 summer transfer window is still open, so the list may need another update after September 1.
